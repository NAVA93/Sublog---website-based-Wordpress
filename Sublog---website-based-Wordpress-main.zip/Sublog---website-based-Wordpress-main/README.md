# Sublog---website-based-Wordpress
A platform designed to connect landlords to marlogs for need - mostly companies
